import React from 'react';
import {View, Text} from 'react-native';
export default function Contact() {
  return (
    <View>
      <Text> Estamos en Contact </Text>
    </View>
  );
}
